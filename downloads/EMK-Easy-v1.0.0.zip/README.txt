EMK Easy v1.0.0

1. แตกไฟล์ ZIP
2. ดับเบิลคลิก EMK-Easy.html เปิดใน Chrome หรือ Edge
3. เลือกไฟล์ EMK เลือกรูปแบบ แล้วกดแปลงไฟล์
4. กดดาวน์โหลด ZIP เพื่อรับผลลัพธ์

ทำงานแบบออฟไลน์ ไม่ต้องติดตั้งโปรแกรม
รองรับ EMK V2

Source: https://github.com/cushyam555/emk-easy
