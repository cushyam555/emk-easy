EMK Easy v1.0.1 — Windows x64

1. แตก ZIP แล้วดับเบิลคลิก EMK-Easy.exe
2. เลือกเพลง EMK เลือก MIDI หรือ NCN แล้วกดแปลงไฟล์
3. กดบันทึก ZIP และเลือกตำแหน่งบันทึก

ใช้ได้แบบออฟไลน์ ต้องมี Microsoft Edge WebView2 Runtime
ติดตั้ง Runtime: https://developer.microsoft.com/microsoft-edge/webview2/

ตัวแปลงและระบบบันทึกผ่านการทดสอบอัตโนมัติ ตัว EXE สร้างบน Linux และยังไม่ได้ทดสอบเปิดหน้าต่างจริงบน Windows

Source: https://github.com/cushyam555/emk-easy
